import pandas as pd
from sklearn.model_selection import train_test_split

# 读取数据
df = pd.read_csv('TRPV4.csv')

# 划分数据为训练集和测试集，按照8:2的比例
train_set, test_set = train_test_split(df, test_size=0.2, random_state=42)  # 使用random_state以保证可重复性

# 保存训练集和测试集到新的CSV文件
train_set.to_csv('TRPV4_train.csv', index=False)  # 不保存行索引
test_set.to_csv('TRPV4_test.csv', index=False)  # 不保存行索引

print("数据集已分割完成并保存。训练集和测试集的数量分别为：", len(train_set), "和", len(test_set))
