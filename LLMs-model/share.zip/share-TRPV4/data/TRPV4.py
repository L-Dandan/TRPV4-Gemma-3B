import csv

# 指定输入CSV文件和输出TXT文件的路径
input_csv_file = 'TRPV4.csv'
output_txt_file = 'TRPV4.txt'

# 打开CSV文件并读取内容
with open(input_csv_file, mode='r', newline='', encoding='utf-8') as csv_file:
    reader = csv.reader(csv_file)
    
    # 创建或打开TXT文件用于写入
    with open(output_txt_file, mode='w', newline='', encoding='utf-8') as txt_file:
        # 跳过标题行（第一行），直接读取后续行的第一列
        next(reader)  # 这一步跳过CSV的头部（即字段标题）
        for row in reader:
            if row:  # 确保行不为空
                txt_file.write(row[0] + '\n')  # 写入第一列的值并添加换行符

print("处理完成，第一列已保存到TXT文件。")
